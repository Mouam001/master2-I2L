package tpintrospection;

import java.util.Vector;

public class Main {

    public static void main(String[] args) {
        try {
            Vector cadeaux = PapiBarbu.vaChercherLesCadeaux();
            System.out.println("Ouh le gros cadeau que voilà ! Voyons voir ce qu'il y a dedans...\n ");

            for (Object cadeau: cadeaux)
                introspect(cadeau);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void introspect(Object o) {
        /**
         * C'est ici qu'il faut compléter !
         **/

    }


}
