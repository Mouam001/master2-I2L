import drawing.shapes.IShape;
import drawing.ui.PaintApplication;
import drawing.shapes.ShapeAdapter;
import javafx.scene.input.KeyCode;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.stage.Stage;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import org.junit.Test;
import org.testfx.framework.junit.ApplicationTest;

import java.util.Iterator;

import static org.junit.Assert.*;

public class PaintTest extends ApplicationTest {

    PaintApplication app;

    @Override
    public void start(Stage stage) {
        try {
            app = new PaintApplication();
            app.start(stage);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Shape create_shape(String shapeType) {
        int x = 20 + get_nb_shapes() * 150;
        int y = 20 + (int) (200 * Math.random());
        int w = 50 + (int) (70 * Math.random());
        clickOn(shapeType);
        moveTo(app.getDrawingPane())
                .moveBy(-app.WIDTH / 2 + x, -app.HEIGHT / 2 + y)
                .drag().dropBy(w, w);
        return (Shape) app.getDrawingPane().getChildren().get(app.getDrawingPane().getChildren().size() - 1);
    }

    private int get_nb_shapes() {
        int nb = 0;
        for (IShape s : app.getDrawingPane())
            nb++;
        return nb;
    }

    private int get_nb_selected() {
        int nb = 0;
        for (IShape s : app.getDrawingPane().getSelection())
            nb++;
        return nb;
    }


    @Test
    public void should_draw_circle_programmatically() {
        interact(() -> {
            app.getDrawingPane().addShape(new ShapeAdapter(new Ellipse(20, 20, 30, 30)));
        });
        Iterator<IShape> it = app.getDrawingPane().getShapes().iterator();
        IShape shape = it.next();
        assertTrue(((ShapeAdapter) shape).getAdaptedShape() instanceof Ellipse);
        assertFalse(it.hasNext());
    }

    @Test
    public void should_draw_circle() {
        // given:
        clickOn("Circle");
        moveBy(60, 60);

        // when:
        drag().dropBy(30, 30);
        //press(MouseButton.PRIMARY); moveBy(30,30); release(MouseButton.PRIMARY);

        // then:
        Iterator<IShape> it = app.getDrawingPane().getShapes().iterator();
        IShape shape = it.next();
        assertTrue(((ShapeAdapter) shape).getAdaptedShape() instanceof Ellipse);
        assertFalse(it.hasNext());
    }

    @Test
    public void should_draw_rectangle() {
        // given:
        clickOn("Rectangle");
        moveBy(0, 60);

        // when:
        drag().dropBy(70, 40);

        // then:
        Iterator<IShape> it = app.getDrawingPane().getShapes().iterator();
        IShape shape = it.next();
        assertTrue(((ShapeAdapter) shape).getAdaptedShape() instanceof Rectangle);
        assertFalse(it.hasNext());
    }

    @Test
    public void should_draw_triangle() {
        //given
        clickOn("Triangle");
        moveBy(40, 50);

        //when:
        drag().dropBy(160, 160);

        //then
        Iterator<IShape> it = app.getDrawingPane().getShapes().iterator();
        IShape shape = it.next();
        assertTrue(((ShapeAdapter) shape).getAdaptedShape() instanceof javafx.scene.shape.Polygon);
        assertFalse(it.hasNext());

    }

    @Test
    public void should_update_statutbar_when_shapes_change() {

        interact(() ->
                app.getDrawingPane().addShape(new ShapeAdapter(new Rectangle(0, 0, 50, 50)))
        );

        HBox bar = (HBox) app.getDrawingPane().getParent().lookup(".statusbar");
        Label lblShapes = (Label) bar.getChildren().get(0);

        assertEquals("Formes : 1", lblShapes.getText());

        interact(() -> app.getDrawingPane().clear());

        assertEquals("Formes : 0", lblShapes.getText());
    }

    @Test
    public void should_update_selection_statusBar() {

        interact(() -> {
            app.getDrawingPane().addShape(new ShapeAdapter(new Rectangle(0, 0, 50, 50)));
            app.getDrawingPane().addShape(new ShapeAdapter(new Rectangle(0, 0, 50, 50)));
        });

        HBox bar = (HBox) app.getDrawingPane().getParent().lookup(".statusbar");
        Label lblSelection = (Label) bar.getChildren().get(1);

        moveTo(10, 10).clickOn();

        assertEquals("Sélectionnées : 1", lblSelection.getText());
    }

    @Test
    public void should_select_multiple() {

        Shape s1 = create_shape("Rectangle");
        Shape s2 = create_shape("Circle");

        assertEquals(2, get_nb_shapes());
        assertEquals(0, get_nb_selected());

        clickOn(s1);                   // 1 sélectionnée
        assertEquals(1, get_nb_selected());

        press(KeyCode.SHIFT)
                .moveTo(s2).clickOn(); // sélection multiple
        release(KeyCode.SHIFT);

        assertEquals(2, get_nb_selected());
    }

    @Test
    public void should_clear() {
        // given:
        clickOn("Rectangle");
        moveBy(30, 60).drag().dropBy(70, 40);
        clickOn("Circle");
        moveBy(-30, 160).drag().dropBy(70, 40);

        // when:
        clickOn("Clear");

        // then:
        assertFalse(app.getDrawingPane().getShapes().iterator().hasNext());
    }


    @Test
    public void should_delete_selected_shapes() {
        Shape s1 = create_shape("Rectangle");
        Shape s2 = create_shape("Circle");

        assertEquals(2, get_nb_shapes());
        assertEquals(0, get_nb_selected());

        clickOn(s1);
        assertEquals(1, get_nb_selected());

        clickOn("Delete");

        assertEquals(1, get_nb_shapes());
        assertEquals(0, get_nb_selected());
    }
}

//@Test
    /*public void show_update_statutsbar_when_shapes_shape(){
        interact(() -> {
            app.getDrawingPane().addShape(new ShapeAdapter( new Rectangle(0, 0, 50, 50)));
        });
        Label label = (Label) ((HBox) app.getDrawingPane().getParent().lookup(".statusbar")).getChildren().get(0);
        assertEquals("Formes : 1", label.getText());

        interact(() -> {
            app.getDrawingPane().clear();
        });
        assertEquals("Formes : 0", label.getText());
    }*/

    /*@Test
    public void show_update_selection_statusBar(){
        interact(() -> {
            app.getDrawingPane().addShape(new ShapeAdapter( new Rectangle(0, 0, 50, 50)));
            app.getDrawingPane().addShape(new ShapeAdapter( new Rectangle(0, 0, 50, 50)));
        });

        Label label = (Label) ((HBox) app.getDrawingPane().getParent().lookup(".statusbar")).getChildren().get(1);

       moveTo(10, 10).clickOn();

       assertEquals("Selectionnées : 1", label.getText());
    }*/


