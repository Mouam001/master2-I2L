package drawing.commands;

import drawing.shapes.IShape;
import drawing.ui.DrawingPane;

import java.util.ArrayList;
import java.util.List;

public class DeleteCommand implements ICommand {
    private DrawingPane drawingPane;
    private List<IShape> deleted = new ArrayList<>();

    public DeleteCommand(DrawingPane drawingPane) {
        this.drawingPane = drawingPane;
    }

    @Override
    public void execute() {
        deleted =  new ArrayList<>(drawingPane.getSelection());

        for(IShape shape : deleted) {
            drawingPane.removeShape(shape);
        }
        drawingPane.clearSelection();
    }

    @Override
    public void undo() {
       // drawingPane.removeShape();
    }
}
