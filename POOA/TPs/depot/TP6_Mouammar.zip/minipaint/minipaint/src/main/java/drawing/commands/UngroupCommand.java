package drawing.commands;

import drawing.shapes.GroupeShape;
import drawing.shapes.IShape;
import drawing.ui.DrawingPane;

import java.util.List;

public class UngroupCommand implements ICommand {
    private final DrawingPane drawingPane;
    private final List<IShape> children;
    private GroupeShape groupeShape;

    public UngroupCommand(DrawingPane drawingPane,GroupeShape groupeShape) {
        this.drawingPane = drawingPane;
        this.groupeShape = groupeShape;
        this.children = groupeShape.getChildren();
    }

    @Override
    public void execute() {
        drawingPane.removeShape(groupeShape);

        for (IShape shape : children) {
            drawingPane.addShape(shape);
        }
    }

    @Override
    public void undo() {
        for (IShape shape : children) {
            drawingPane.removeShape(shape);
        }
        drawingPane.addShape(groupeShape);
    }
}
