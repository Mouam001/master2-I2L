package drawing.commands;

import drawing.shapes.IShape;
import drawing.ui.DrawingPane;

import java.util.ArrayList;
import java.util.List;

public class BringToFrontCommand implements ICommand {
    private final DrawingPane drawingPane;
    private final List<IShape> selection;
    private final List<Integer> oldIndexes = new ArrayList<>();

    public BringToFrontCommand(DrawingPane drawingPane, List<IShape> selection) {
        this.drawingPane = drawingPane;
        this.selection = selection;
    }

    @Override
    public void undo() {
        for(int i =0;i< selection.size(); i++){
            IShape shape = selection.get(i);
            int index = oldIndexes.get(i);
            drawingPane.getChildren().remove(shape.getAdaptedShape());
            drawingPane.getChildren().add(index, shape.getAdaptedShape());
        }
    }

    @Override
    public void execute() {
        for(IShape shape : selection) {
            int index = drawingPane.getChildren().indexOf(shape.getAdaptedShape());
            oldIndexes.add(index);
            shape.getAdaptedShape();
        }
    }
}
