package drawing.handlers;

import drawing.commands.GroupCommand;
import drawing.commands.ICommand;
import drawing.ui.DrawingPane;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class GroupButtonHandler implements EventHandler<ActionEvent>  {
    private final DrawingPane drawingPane;

    public GroupButtonHandler(DrawingPane drawingPane) {
        this.drawingPane = drawingPane;
    }

    @Override
    public void handle(ActionEvent event) {
       if(drawingPane.getSelection().size() < 2) return;

        ICommand cmd = new GroupCommand(
                drawingPane,
                drawingPane.getSelection()
        );
        drawingPane.getCommandHistory().exec(cmd);
    }
}
