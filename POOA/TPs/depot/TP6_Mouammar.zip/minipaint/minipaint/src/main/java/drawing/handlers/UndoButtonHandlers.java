package drawing.handlers;

import drawing.ui.DrawingPane;
import javafx.event.EventHandler;
import javafx.event.ActionEvent;

public class UndoButtonHandlers implements EventHandler<ActionEvent> {
    private final DrawingPane drawingPane;

    public UndoButtonHandlers(DrawingPane drawingPane) {
        this.drawingPane = drawingPane;
    }

    @Override
    public void handle(ActionEvent event) {
        drawingPane.getCommandHistory().undo();
    }
}
