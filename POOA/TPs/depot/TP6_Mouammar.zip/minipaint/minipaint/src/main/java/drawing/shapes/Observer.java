package drawing.shapes;

public interface Observer {
    public void update();
}
