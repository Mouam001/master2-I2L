package drawing.handlers;

import drawing.commands.DeleteCommand;
import drawing.commands.ICommand;
import drawing.shapes.IShape;
import drawing.ui.DrawingPane;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class DeleteButtonHandler implements EventHandler<ActionEvent> {

    private final ICommand command;
    private final DrawingPane drawingPane;
    public DeleteButtonHandler(DrawingPane drawingPane) {
        this.drawingPane = drawingPane;
        this.command = new DeleteCommand(drawingPane);
    }

    @Override
    public void handle(ActionEvent actionEvent) {
        drawingPane.getCommandHistory().exec(command);
    }
}
