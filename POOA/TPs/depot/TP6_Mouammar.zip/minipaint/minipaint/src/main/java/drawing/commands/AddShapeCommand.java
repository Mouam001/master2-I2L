package drawing.commands;

import drawing.shapes.IShape;
import drawing.ui.DrawingPane;

public class AddShapeCommand implements ICommand {
    private final DrawingPane drawingPane;
    private final IShape shape;

    public AddShapeCommand(DrawingPane drawingPane, IShape shape) {
        this.drawingPane = drawingPane;
        this.shape = shape;
    }

    @Override
    public void undo() {
       drawingPane.removeShape(shape);
    }

    @Override
    public void execute() {
        drawingPane.addShape(shape);
    }
}
