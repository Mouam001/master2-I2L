package drawing.handlers;

import drawing.commands.BringToFrontCommand;
import drawing.commands.ICommand;
import drawing.ui.DrawingPane;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class BringToFrontHandler implements EventHandler<ActionEvent> {
    private final DrawingPane drawingPane;
    public BringToFrontHandler(DrawingPane drawingPane) {
        this.drawingPane = drawingPane;
    }

    @Override
    public void handle(ActionEvent event) {
       if(drawingPane.getSelection().isEmpty()) return;
        ICommand command = new BringToFrontCommand(
                drawingPane,
                drawingPane.getSelection()
        );
        drawingPane.getCommandHistory().exec(command);
    }
}
