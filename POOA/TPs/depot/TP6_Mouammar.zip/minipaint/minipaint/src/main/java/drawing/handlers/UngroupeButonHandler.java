package drawing.handlers;

import drawing.commands.ICommand;
import drawing.commands.UngroupCommand;
import drawing.shapes.GroupeShape;
import drawing.shapes.IShape;
import drawing.ui.DrawingPane;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

import java.util.List;

public class UngroupeButonHandler implements EventHandler<ActionEvent> {
    private final DrawingPane drawingPane;

    public UngroupeButonHandler(DrawingPane drawingPane) {
        this.drawingPane = drawingPane;
    }

    @Override
    public void handle(ActionEvent event) {
       if(drawingPane.getSelection().size() != 1) return;

       if(!(drawingPane.getSelection().get(0) instanceof GroupeShape)) return;

       GroupeShape groupeShape = (GroupeShape) drawingPane.getSelection().get(0);

        ICommand cmd = new UngroupCommand(drawingPane, groupeShape);
        drawingPane.getCommandHistory().exec(cmd);
    }
}


