package drawing.commands;

import java.util.Stack;

public class CommandHistory {

    private final Stack<ICommand> undoStack = new Stack<>();
    private final Stack<ICommand> redoStack = new Stack<>();

    public void exec(ICommand cmd) {
        cmd.execute();
        undoStack.push(cmd);
        redoStack.push(cmd);
    }
    // Annuler
    public void undo() {
        if(undoStack.isEmpty()) return;

        ICommand cmd = undoStack.pop();
        cmd.undo();
        redoStack.push(cmd);
    }

    // Refaire
    public void redo(){
        if(redoStack.isEmpty()) return;

        ICommand cmd = redoStack.pop();
        cmd.execute();
        undoStack.push(cmd);
    }


}
