package drawing.commands;

import drawing.shapes.IShape;
import drawing.ui.DrawingPane;

import java.util.ArrayList;
import java.util.List;

public class ClearCommand implements ICommand {
    private final DrawingPane drawingPane;
    private List<IShape> backup = new ArrayList<>();

    public ClearCommand(DrawingPane drawingPane) {
        this.drawingPane = drawingPane;
    }

    @Override
    public void execute() {
        // sauvegarde avant supression
        backup = new ArrayList<>(drawingPane.getShapes());
        drawingPane.clear();
    }

    @Override
    public void undo() {
        for(IShape shape : backup) {
            drawingPane.getShapes().add(shape);
            shape.addShapeToPane(drawingPane);
        }
        drawingPane.notifyObservers();
    }
}
