package drawing.commands;

import drawing.shapes.GroupeShape;
import drawing.shapes.IShape;
import drawing.ui.DrawingPane;

import java.util.ArrayList;
import java.util.List;

public class GroupCommand implements ICommand {
    private final DrawingPane drawingPane;
    private final List<IShape> selected;
    private GroupeShape groupeShape;

    public GroupCommand(DrawingPane drawingPane, List<IShape> selected) {
        this.drawingPane = drawingPane;
        this.selected = selected;
    }

    @Override
    public void undo() {
        drawingPane.removeShape(groupeShape);
        for(IShape shape : selected) {
            drawingPane.addShape(shape);
        }
    }

    @Override
    public void execute() {
        if (selected.size() < 2) return ;

        for(IShape shape : selected) {
            drawingPane.removeShape(shape);
        }

        groupeShape = new GroupeShape(selected);
        drawingPane.addShape(groupeShape);
    }
}
