package drawing.ui;

import drawing.shapes.Observer;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.geometry.Insets;

public class StatutBar extends HBox implements Observer {
    private Label label;
    private Label labelSelection;
    private DrawingPane drawingPane;

    public StatutBar(DrawingPane drawingPane) {
        this.drawingPane = drawingPane;
        label = new Label("Forms : 0");
        labelSelection = new Label("Selection : 0");

        this.getChildren().addAll(label, labelSelection);
        this.setPadding(new Insets(5));
        this.setSpacing(5);
        this.getStyleClass().add("statusbar");
        this.drawingPane.addObserver(this);
    }

    public void update(){
        label.setText("Formes : " + drawingPane.getShapeCount());
        labelSelection.setText("Sélectionnées : " + drawingPane.getSelection().size());

    }


}
