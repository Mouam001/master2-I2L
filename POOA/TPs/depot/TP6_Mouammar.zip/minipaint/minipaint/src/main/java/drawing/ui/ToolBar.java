package drawing.ui;

import drawing.commands.RedoButtonHandler;
import drawing.handlers.*;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;

public class ToolBar extends HBox {
    private Button clearButton;
    private Button rectangleButton;
    private Button circleButton;
    private Button triangleButton;
    private StatutBar statutBar;
    private Button deleteButton, groupButton, ungroupButton , bringToFrontButton, undoButton, redoButton;

    public ToolBar(DrawingPane drawingPane) {
        this.setPadding(new Insets(5));
        this.setSpacing(5);
        this.getStyleClass().add("toolbar");

        //La factory
        ButtonFactory btnFactory = new ButtonFactory(ButtonFactory.ICONS_ONLY);

        //Les Boutons
        clearButton = btnFactory.createButton(ButtonFactory.CLEAR);
        clearButton.addEventFilter(ActionEvent.ACTION, new ClearButtonHandler(drawingPane));

        rectangleButton = btnFactory.createButton(ButtonFactory.RECT);
        rectangleButton.addEventFilter(ActionEvent.ACTION, new RectangleButtonHandler(drawingPane));

        circleButton = btnFactory.createButton(ButtonFactory.CIRCLE);
        circleButton.addEventFilter(ActionEvent.ACTION, new EllipseButtonHandler(drawingPane));

        triangleButton = btnFactory.createButton(ButtonFactory.TRIANGLE);
        triangleButton.addEventFilter(ActionEvent.ACTION, new TriangleButtonHandler(drawingPane));

        deleteButton = btnFactory.createButton(ButtonFactory.DELETE);
        deleteButton.addEventFilter(ActionEvent.ACTION, new DeleteButtonHandler(drawingPane));

        groupButton = btnFactory.createButton(ButtonFactory.GROUP);
        groupButton.addEventFilter(ActionEvent.ACTION, new GroupButtonHandler(drawingPane));

        ungroupButton = btnFactory.createButton(ButtonFactory.UNGROUP);
        ungroupButton.addEventFilter(ActionEvent.ACTION, new UngroupeButonHandler(drawingPane));

        bringToFrontButton = btnFactory.createButton(ButtonFactory.BRING_FRONT);
        bringToFrontButton.addEventFilter(ActionEvent.ACTION, new BringToFrontHandler(drawingPane));

        undoButton = btnFactory.createButton(ButtonFactory.UNDO);
        undoButton.addEventFilter(ActionEvent.ACTION, new UndoButtonHandlers(drawingPane));

        redoButton = btnFactory.createButton(ButtonFactory.REDO);
        redoButton.addEventFilter(ActionEvent.ACTION, new RedoButtonHandler(drawingPane));

        this.getChildren().addAll(clearButton,rectangleButton, circleButton, triangleButton, deleteButton, groupButton, ungroupButton, bringToFrontButton, undoButton, redoButton);


    }
}
