package drawing.shapes;

import javafx.beans.binding.Bindings;
import javafx.beans.value.ObservableNumberValue;
import javafx.beans.value.ObservableValue;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;
import javafx.scene.shape.Path;
import javafx.scene.shape.Shape;

import javax.naming.Binding;

public class Edge implements IShape{

    private final IShape from;
    private final IShape to;
    private final Path path = new Path();
    private IEdgeStrategy strategy;

    private boolean selected = false;

    public Edge(IShape from, IShape to, IEdgeStrategy strategy) {
        this.from = from;
        this.to = to;
        this.strategy = strategy;
        rebuildPath();

        // Binding des extremités
       // path.startXProperty().bind(from.centerXProperty());
        //path.startYProperty().bind(from.centerYProperty());
       // path.endXProperty().bind(to.centerXProperty());
       // path.endYProperty().bind(to.centerYProperty());
    }

    private void rebuildPath(){
        strategy.buildPath(from, to, path);
    }

    @Override
    public void addShapeToPane(Pane pane){
        pane.getChildren().add(path);
    }

    @Override
    public void removeShapeFromPane(Pane pane){
        pane.getChildren().remove(path);
    }

    @Override
    public boolean isOn(double x, double y){
        return path.contains(x, y);
    }

    @Override
    public void offset(double x, double y){}

    @Override
    public boolean isSelected(){
        return selected;
    }

    @Override
    public void setSelected(boolean selected){
        this.selected = selected;
        if(selected){
            if(!path.getStyleClass().contains("selected")){
                path.getStyleClass().add("selected");
            }else {
                path.getStyleClass().remove("selected");
            }
        }
    }

    @Override
    public Shape getAdaptedShape(){
        return path;
    }

    @Override
    public IShape duplicate() {
        throw new UnsupportedOperationException("Un Edge ne peux pas être dupliqué");
    }

    @Override
    public ObservableValue<Number> centerXProperty() {
        return Bindings.createDoubleBinding(
                () -> (from.centerXProperty().getValue().doubleValue()
                        + to.centerXProperty().getValue().doubleValue()) / 2,
                from.centerXProperty(),
                to.centerXProperty()
        );
    }

    @Override
    public ObservableValue<Number> centerYProperty() {
        return Bindings.createDoubleBinding(
                () -> (from.centerYProperty().getValue().doubleValue()
                        + to.centerYProperty().getValue().doubleValue()) / 2,
                from.centerYProperty(),
                to.centerYProperty()
        );
    }

 public IEdgeStrategy getStrategy(){
        return strategy;
    }
 public void setEdgeStrategy(IEdgeStrategy strategy){
        this.strategy = strategy;
        rebuildPath();
 }
}
