package drawing.shapes;

import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;

import javafx.scene.shape.Path;

public class StraightEdgeStrategy implements IEdgeStrategy {

    @Override
    public void buildPath(IShape from, IShape to, Path path){
        path.getElements().clear();

        MoveTo move = new MoveTo();

        //POint de depart
        move.xProperty().bind(to.centerXProperty());
        move.yProperty().bind(to.centerYProperty());

        // Point d'arrivé
        LineTo line = new LineTo();
        line.xProperty().bind(to.centerXProperty());
        line.yProperty().bind(to.centerYProperty());

        path.getElements().addAll(move, line);
    }
}
