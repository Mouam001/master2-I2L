package drawing.commands;

import drawing.exceptions.CommandException;
import drawing.shapes.Edge;
import drawing.shapes.IShape;
import drawing.shapes.OrthogonalEdgeStrategy;
import drawing.shapes.StraightEdgeStrategy;
import drawing.ui.DrawingPane;

import java.util.List;

public class AddEdgeCommand implements ICommand{
    private final DrawingPane drawingPane;
    private Edge edge;

    public AddEdgeCommand(DrawingPane drawingPane){
        this.drawingPane = drawingPane;
    }

    @Override
    public void execute() {
        List<IShape> shape = drawingPane.getSelection();
        if(shape.size() != 2) {
            throw new CommandException("Selectionner exactement 2 formes");
        }
        edge = new Edge(shape.get(0),
                shape.get(1),
                new StraightEdgeStrategy()
        );
        drawingPane.addShape(edge);
    }

    @Override
    public void undo() {
        drawingPane.removeShape(edge);
    }
}
