package drawing.commands;

import drawing.exceptions.CommandException;
import drawing.shapes.Edge;
import drawing.shapes.IEdgeStrategy;
import drawing.shapes.IShape;
import drawing.ui.DrawingPane;

import java.util.ArrayList;
import java.util.List;

public class ApplyEdgeStrategyCommand implements ICommand{

    private final DrawingPane drawingPane;
    private IEdgeStrategy edgeStrategy;

    private final List<Edge> modfieEdges = new ArrayList<>();
    private final List<IEdgeStrategy> oldStrategy = new ArrayList<>();

    public ApplyEdgeStrategyCommand(DrawingPane drawingPane, IEdgeStrategy edgeStrategy) {
        this.drawingPane = drawingPane;
        this.edgeStrategy = edgeStrategy;
    }

    @Override
    public void execute() {
        List<IShape> selection = new DrawingPane().getSelection();

        if(selection.isEmpty()){
            throw new CommandException(" Aucun Edge selectionné");
        }

        for(IShape shape : selection){
            if(shape instanceof Edge edge){
                modfieEdges.add(edge);
                oldStrategy.add(edge.getStrategy());
                edge.setEdgeStrategy(edgeStrategy);
            }
        }
        if(modfieEdges.isEmpty()){
            throw new CommandException(" La selectiin ne contient aucun Edge");
        }
    }

    @Override
    public void undo() {
        for(int i = 0; i < modfieEdges.size(); i++){
            modfieEdges.get(i).setEdgeStrategy(oldStrategy.get(i));
        }
    }
}
