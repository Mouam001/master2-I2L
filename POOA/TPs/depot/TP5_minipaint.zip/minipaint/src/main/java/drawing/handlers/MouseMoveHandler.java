package drawing.handlers;

import drawing.shapes.IShape;
import drawing.ui.DrawingPane;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

/**
 * Created by lewandowski on 20/12/2020.
 */
public class MouseMoveHandler implements EventHandler<MouseEvent> {

    private DrawingPane drawingPane;

    private double orgSceneX;
    private double orgSceneY;


    private IShape selectedShape;

    public MouseMoveHandler(DrawingPane drawingPane) {
        this.drawingPane = drawingPane;
        drawingPane.addEventHandler(MouseEvent.MOUSE_PRESSED, this);
        drawingPane.addEventHandler(MouseEvent.MOUSE_DRAGGED, this);
        drawingPane.addEventHandler(MouseEvent.MOUSE_RELEASED, this);
    }

    @Override
    public void handle(MouseEvent event) {
        if (event.getEventType().equals(MouseEvent.MOUSE_PRESSED)) {
            orgSceneX = event.getSceneX();
            orgSceneY = event.getSceneY();
        }

        if (event.getEventType().equals(MouseEvent.MOUSE_DRAGGED)) {
            double offsetX = event.getSceneX() - orgSceneX;
            double offsetY = event.getSceneY() - orgSceneY;

            for(IShape shape : drawingPane.getSelection())
                shape.offset(offsetX, offsetY);

            orgSceneX = event.getSceneX();
            orgSceneY = event.getSceneY();
        }
    }
    /*public void handle(MouseEvent event) {
        // MOusse Pressed :
        if(event.getEventType().equals(MouseEvent.MOUSE_PRESSED)) {
            orgSceneX = event.getSceneX();
            orgSceneY = event.getSceneY();
        }

        // Mouse Dragged
        if(event.getEventType().equals(MouseEvent.MOUSE_DRAGGED)) {

            var selection = drawingPane.getSelection();
            if(selection.isEmpty()) return;

            double offsetX = event.getSceneX() - orgSceneX;
            double offsetY = event.getSceneY() - orgSceneY;

            //deplacer chaque forme
            for(IShape s : selection) {
                s.offset(offsetX, offsetY);
            }

            //MAJ position d'origine pour la prochaine drag
            orgSceneX = event.getSceneX();
            orgSceneY = event.getSceneY();
        }
        if(event.getEventType().equals(MouseEvent.MOUSE_RELEASED)) {

        }
    }*/
}
