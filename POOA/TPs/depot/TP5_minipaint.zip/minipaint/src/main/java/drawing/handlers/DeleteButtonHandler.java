package drawing.handlers;

import drawing.shapes.IShape;
import drawing.ui.DrawingPane;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class DeleteButtonHandler implements EventHandler<ActionEvent> {
    private final DrawingPane drawingPane;

    public DeleteButtonHandler(DrawingPane drawingPane) {
        this.drawingPane = drawingPane;
    }

    @Override
    public void handle(ActionEvent actionEvent) {
        var deletes = new java.util.ArrayList<>(drawingPane.getSelection());
        for(IShape shape : deletes) {
            drawingPane.removeShape(shape);
        }
        drawingPane.clearSelection();
       // drawingPane.clear();
    }
}
