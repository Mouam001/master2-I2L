package drawing.handlers;

import drawing.shapes.IShape;
import drawing.ui.DrawingPane;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class BringToFrontHandler implements EventHandler<ActionEvent> {
    private final DrawingPane drawingPane;

    public BringToFrontHandler(DrawingPane drawingPane) {
        this.drawingPane = drawingPane;
    }

    @Override
    public void handle(ActionEvent event) {
        var selection = drawingPane.getSelection();
        if(selection.isEmpty()) return;

        IShape shape = selection.get(0);
        shape.getAdaptedShape().toFront();

        drawingPane.notifySelectionChanged();
    }
}
