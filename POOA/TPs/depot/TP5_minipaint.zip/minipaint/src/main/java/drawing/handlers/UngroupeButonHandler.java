package drawing.handlers;

import drawing.shapes.GroupeShape;
import drawing.shapes.IShape;
import drawing.ui.DrawingPane;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

import java.util.List;

public class UngroupeButonHandler implements EventHandler<ActionEvent> {
    private final DrawingPane drawingPane;

    public UngroupeButonHandler(DrawingPane drawingPane) {
        this.drawingPane = drawingPane;
    }

    @Override
    public void handle(ActionEvent event) {
       if(drawingPane.getSelection().size() != 1) return;

       IShape selectedShape = drawingPane.getSelection().get(0);
       if(!(selectedShape instanceof GroupeShape)) return;

       GroupeShape groupShape = (GroupeShape) selectedShape;

       // Remove group from drawing
        drawingPane.removeShape(groupShape);

        // Add children
        for(IShape child : groupShape.getChildren()) {
            drawingPane.addShape(child);
        }

       drawingPane.clearSelection();
    }
}


