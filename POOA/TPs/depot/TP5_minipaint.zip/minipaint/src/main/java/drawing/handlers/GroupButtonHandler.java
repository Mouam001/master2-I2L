package drawing.handlers;

import drawing.shapes.GroupeShape;
import drawing.shapes.IShape;
import drawing.ui.DrawingPane;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

import java.util.ArrayList;
import java.util.List;

public class GroupButtonHandler implements EventHandler<ActionEvent>  {
    private final DrawingPane drawingPane;

    public GroupButtonHandler(DrawingPane drawingPane) {
        this.drawingPane = drawingPane;
    }

    @Override
    public void handle(ActionEvent event) {
        List<IShape> selected = new ArrayList<>(drawingPane.getSelection());
        if(selected.size() < 2) return;

        // Retirer les formes du DrawingPane porporement
        for(IShape shape : selected) {
            drawingPane.removeShape(shape);
        }

        //Creation nuveau groupe
        GroupeShape group = new GroupeShape(selected);
        drawingPane.addShape(group);

        //Reinitilisation de la selection
        drawingPane.clearSelection();
        group.setSelected(true);
        drawingPane.getSelection().add(group);
    }
}
