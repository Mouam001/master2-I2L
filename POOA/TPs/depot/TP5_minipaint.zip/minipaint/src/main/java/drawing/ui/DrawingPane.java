package drawing.ui;

import drawing.handlers.MouseMoveHandler;
import drawing.shapes.Observer;
import drawing.handlers.SelectionHandler;
import drawing.shapes.IShape;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;
import javafx.scene.shape.Rectangle;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by lewandowski on 20/12/2020.
 */
public class DrawingPane extends Pane implements Iterable<IShape> {

    private MouseMoveHandler mouseMoveHandler;
    private SelectionHandler selectionHandler;

    private ArrayList<IShape> shapes;
    private final List<Observer> oberservers;

    public DrawingPane() {
        shapes = new ArrayList<>();
        oberservers = new ArrayList<>();
        clipChildren();
        // handlers
        mouseMoveHandler = new MouseMoveHandler(this);
        selectionHandler = new SelectionHandler(this);
    }

    //ajout observater
    public void addObserver(Observer observer) {
        oberservers.add(observer);
    }

    public void notifyObservers() {
        for (Observer obs : oberservers) {
            obs.update();
        }
    }

    public void notifySelectionChanged() {
        notifyObservers();
    }

    /**
     * Clips the children of this {@link Region} to its current size.
     * This requires attaching a change listener to the region’s layout bounds,
     * as JavaFX does not currently provide any built-in way to clip children.
     */
    void clipChildren() {
        final Rectangle outputClip = new Rectangle();
        this.setClip(outputClip);

        this.layoutBoundsProperty().addListener((ov, oldValue, newValue) -> {
            outputClip.setWidth(newValue.getWidth());
            outputClip.setHeight(newValue.getHeight());
        });
    }

    public void addShape(IShape shape) {
        shapes.add(shape);
        shape.addShapeToPane(this);
        notifyObservers();
    }

    public void removeShape(IShape shape) {
        shapes.remove(shape);
        shape.removeShapeFromPane(this);
        notifyObservers();
    }

    public ArrayList<IShape> getShapes() {
        return shapes;
    }

    @Override
    public Iterator<IShape> iterator() {
        return shapes.iterator();
    }

    public int getShapeCount() {
        return shapes.size();
    }

    public List<IShape> getSelection() {
        return selectionHandler.getSelection();
    }

    public void clear() {
        for (IShape shape : shapes) {
            shape.removeShapeFromPane(this);
        }
        shapes.clear();
        notifyObservers();
    }

    //Fixer Bug
    public void clearSelection() {
        selectionHandler.clearSelectionFromOutside();
        notifyObservers();
    }

}
