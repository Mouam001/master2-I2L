package drawing;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;

public class TriangleButtonHandler extends ShapeButtonHandler{
    public TriangleButtonHandler(DrawingPane drawingPane) {
        super(drawingPane);
    }

    @Override
    protected Shape createShape() {
        double x = Math.min(originX, destinationX);
        double y = Math.min(originY, destinationY);
        double width = Math.abs(destinationX - originX);
        double height = Math.abs(destinationY - originY);

        //Triangle
        Polygon triangle = new Polygon();
        triangle.getPoints().addAll(
                x + width/2, y,
                x, y + height,
                x + width, y + height
        );
        triangle.getStyleClass().add("triangle");
        return triangle;
    }
}
