package drawing.commands;

import drawing.exceptions.CommandException;
import drawing.shapes.IShape;
import drawing.shapes.TextShapeDecorator;
import drawing.ui.DrawingPane;

public class AddTextCommand implements ICommand {
    private final DrawingPane drawingPane;
    private IShape originial ;
    private IShape decorated;
    private final String text;

    public AddTextCommand(DrawingPane drawingPane,String text) {
        this.drawingPane = drawingPane;
        this.text = text;
    }

    @Override
    public void execute() {

        if(drawingPane.getSelection().size() != 1){
            throw new CommandException(
                    "Veuillez selectionner une forme"
            );
        }

        originial = drawingPane.getSelection().get(0);
        decorated = new TextShapeDecorator(originial, text);
        drawingPane.removeShape(originial);
        drawingPane.addShape(decorated);

    }

    @Override
    public void undo() {
        drawingPane.removeShape(decorated);
        drawingPane.addShape(originial);
    }
}
