package drawing.shapes;

import java.util.ArrayList;
import java.util.List;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Shape;

public class GroupeShape  implements IShape{
    private List<IShape> children = new ArrayList<>();
    private boolean selected = false;

    public GroupeShape(List<IShape> shapes) {
        children.addAll(shapes);
    }

    public List<IShape> getChildren() {
        return children;
    }

    @Override
    public boolean isSelected() {
        return selected;
    }

    @Override
    public void setSelected(boolean selected) {
        this.selected = selected;

        //selection des enfants
        for(IShape shape : children) {
            shape.setSelected(selected);
        }
    }

    @Override
    public boolean isOn(double x, double y) {
        for(IShape shape : children) {
            if(shape.isOn(x, y)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void offset(double dx, double dy) {
        for(IShape shape : children) {
            shape.offset(dx, dy);
        }
    }

    @Override
    public void addShapeToPane(Pane pane){
        for(IShape shape : children) {
            shape.addShapeToPane(pane);
        }
    }

    @Override
    public void removeShapeFromPane(Pane pane){
        for(IShape shape : children) {
            shape.removeShapeFromPane(pane);
        }
    }

    public Shape getAdaptedShape(){
        return null;
    }

    public IShape duplicate(){
        List<IShape> copies = new ArrayList<>();
        for(IShape shape : children) {
            copies.add(shape.duplicate());
        }
        return new GroupeShape(copies);
    }

}
