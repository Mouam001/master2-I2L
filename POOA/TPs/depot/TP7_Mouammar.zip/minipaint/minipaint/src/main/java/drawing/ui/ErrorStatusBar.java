package drawing.ui;

import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;

public class ErrorStatusBar extends HBox {

    private final Label label = new Label();

    public ErrorStatusBar(){
        this.setPadding(new Insets(5));
        this.getChildren().add(label);
        this.getStyleClass().add("error-status-bar");
    }

    public void showError(String message){
        label.setText(message);
    }

    public void clearError(){
        label.setText("");
    }
}
