package drawing.handlers;

import drawing.commands.DuplicateCommand;
import drawing.commands.ICommand;
import drawing.ui.DrawingPane;
import javafx.event.EventHandler;
import javafx.event.ActionEvent;

public class DuplicateButtonHandler implements EventHandler<ActionEvent> {
    private final DrawingPane drawingPane;

    public DuplicateButtonHandler(DrawingPane drawingPane) {
        this.drawingPane = drawingPane;
    }

    @Override
    public void handle(ActionEvent actionEvent) {
        if(drawingPane.getSelection().isEmpty()) {
            return;
        }

        ICommand command = new DuplicateCommand(
                drawingPane,
                drawingPane.getSelection()
        );
        drawingPane.getCommandHistory().exec(command);
    }
}
