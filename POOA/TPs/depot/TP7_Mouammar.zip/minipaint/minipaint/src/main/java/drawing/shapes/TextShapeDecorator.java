package drawing.shapes;

import drawing.exceptions.CommandException;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;

public class TextShapeDecorator extends AbstractShapeDecorator {

    private final Text text;
    public TextShapeDecorator(IShape shape,  String content) {
        super(shape);

        if(shape instanceof GroupeShape){
            throw new CommandException("Impossible d'ajouter du texte à un groupe");
        }
        text = new Text(content);
    }

    @Override
    public void addShapeToPane(Pane pane){
        super.addShapeToPane(pane);
        pane.getChildren().add(text);
        updateTextPosition();
    }

    @Override
    public void removeShapeFromPane(Pane pane){
        pane.getChildren().remove(text);
        super.removeShapeFromPane(pane);

    }

    @Override
    public void offset(double x, double y){
        super.offset(x, y);
        updateTextPosition();
    }

    private void updateTextPosition(){
        var bounds = getAdaptedShape().getBoundsInParent();
        text.setX(bounds.getMinX() + bounds.getWidth());
        text.setY(bounds.getMinY() + bounds.getHeight());
    }
}
