package drawing.ui;

import javafx.scene.control.Button;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class ButtonFactory {

    public static final int ICONS_ONLY = 1;
    public static final int TEXT_ONLY = 2;
    public static final String GROUP = "GROUP";
    public static final String UNGROUP = "UNGROUP";

    public static final String RECT = "RECT";
    public static final String CIRCLE = "CIRCLE";
    public static final String TRIANGLE = "TRIANGLE";
    public static final String CLEAR = "CLEAR";
    public static final String DELETE = "DELETE";
    public static final String BRING_FRONT = "BRING_FRONT";
    public static final String UNDO = "UNDO";
    public static final String REDO = "REDO";
    public static final String DUPLICATE = "DUPLICATE";
    public static final String ADD = "ADD";


    private final int style;

    public ButtonFactory(int style) {
        this.style = style;
    }

    public Button createButton(String buttonName) {

        Button b = new Button();

        if (style == TEXT_ONLY) {
            b.setText(buttonName);
            return b;
        }

        // Sinon → icônes
        String iconPath = null;
        String tooltipText = "";

        switch (buttonName) {
            case RECT:
                iconPath = "/icons/rectangle-arrondi.png";
                tooltipText = "Rectangle";
                break;

            case CIRCLE:
                iconPath = "/icons/ombre.png";
                tooltipText = "Circle";
                break;

            case TRIANGLE:
                iconPath = "/icons/triangle.png";
                tooltipText = "Triangle";
                break;

            case CLEAR:
                iconPath = "/icons/clear.png";
                tooltipText = "Clear all shapes";
                break;

            case DELETE:
                iconPath = "/icons/delete_.png";
                tooltipText = "Delete selected shapes";
                break;

            case GROUP:
                iconPath = "/icons/groupe.png";
                tooltipText = "GROUP";
                break;

            case UNGROUP:
                iconPath = "/icons/separe.png";
                tooltipText = "UNGROUP";
                break;
            case BRING_FRONT:
                iconPath = "/icons/front.png";
                tooltipText = "btnFront";
                break;

                case UNDO:
                    iconPath = "/icons/undo.png";
                    tooltipText = "btnUndo";
                    break;

            case REDO:
                iconPath = "/icons/redo.png";
                tooltipText = "btnRedo";
                break;
            case DUPLICATE:
                iconPath = "/icons/dupliquer.png";
                tooltipText = "btnDuplicate";
                break;
            case ADD:
                iconPath = "/icons/addText.png";
                tooltipText = "btnAdd";

        }


        Button button = new Button(tooltipText);

        // Charger l’icône
        Image img = new Image(getClass().getResourceAsStream(iconPath));
        ImageView iv = new ImageView(img);
        iv.setFitWidth(20);
        iv.setFitHeight(20);

        // Ajouter l’icône à gauche du texte
        button.setGraphic(iv);
        // Petite marge entre l’icône et le texte
        button.setGraphicTextGap(8);

        return button;
    }
}



