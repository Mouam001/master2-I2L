package drawing.handlers;

import drawing.commands.AddTextCommand;
import drawing.commands.ICommand;
import drawing.ui.DrawingPane;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.TextInputDialog;

public class AddTextButtonHandler implements EventHandler<ActionEvent> {
    private final DrawingPane drawingPane;

    public AddTextButtonHandler(DrawingPane drawingPane) {
        this.drawingPane = drawingPane;
    }

    @Override
    public void handle(ActionEvent event) {
        TextInputDialog dialog = new TextInputDialog("hello");
        dialog.setTitle("Add Text");

        dialog.showAndWait().ifPresent(text -> {
           drawingPane.getCommandHistory().exec(new AddTextCommand(drawingPane, text));
        });
    }
}
