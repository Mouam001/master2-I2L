package drawing.shapes;

import drawing.exceptions.CommandException;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;

public class ShapeAdapter implements IShape {
    private final Shape adaptedShape;
    private boolean selected = false;

    public ShapeAdapter(Shape shape) {
        this.adaptedShape = shape;
    }

    // partie Séléction
    @Override
    public boolean isSelected() {
        return selected;
    }

    @Override
    public void setSelected(boolean selected) {
        this.selected = selected;

        if(selected) {
            if(!adaptedShape.getStyleClass().contains("selected")) {
                adaptedShape.getStyleClass().add("selected");
            }

        } else {
            adaptedShape.getStyleClass().remove("selected");
        }
    }

    // Interaction
    @Override
    public boolean isOn(double x, double y){
        return adaptedShape.getBoundsInParent().contains(x,y);
    }

    @Override
    public void offset(double dx, double dy){
        adaptedShape.setTranslateX(adaptedShape.getTranslateX() + dx);
        adaptedShape.setTranslateY(adaptedShape.getTranslateY() + dy);
    }

    // Pane
    @Override
    public void addShapeToPane(Pane pane){
        pane.getChildren().add(adaptedShape);
    }

    @Override
    public void removeShapeFromPane(Pane pane){
        pane.getChildren().remove(adaptedShape);
    }


    public Shape getAdaptedShape(){
        return adaptedShape;
    }

    // Prototype
    public IShape duplicate(){
        Shape copy = cloneJavaFxShape(adaptedShape);

        // copier Style CSS
        copy.getStyleClass().addAll(adaptedShape.getStyleClass());

        // copier translation
        copy.setTranslateX(adaptedShape.getTranslateX() + 15);
        copy.setTranslateY(adaptedShape.getTranslateY() +15 );

        return new ShapeAdapter(copy);
    }

    private Shape cloneJavaFxShape(Shape shape) {
        if(shape instanceof Rectangle r){
            Rectangle rectangle = new Rectangle(r.getX(), r.getY(), r.getWidth(), r.getHeight());
            rectangle.setArcWidth(r.getArcWidth());
            rectangle.setArcHeight(r.getArcHeight());
            copyPaint(r, rectangle);

        }

        if(shape instanceof Ellipse e){
            Ellipse c = new Ellipse(
                    e.getCenterX(),
                    e.getCenterY(),
                    e.getRadiusX(),
                    e.getRadiusY()
            );

            copyPaint(e, c);
            return c;
        }

        if(shape instanceof Polygon p){
            Polygon polygon = new Polygon();
            polygon.getPoints().addAll(p.getPoints());
            copyPaint(p, polygon);
            return polygon;
        }
        throw new CommandException(
                "dupplication non supporté " + shape.getClass().getSimpleName()
        );
    }

    private void copyPaint(Shape from, Shape to){
            Paint fill = from.getFill();
            Paint stroke = from.getStroke();

            to.setFill(fill);
            to.setStroke(stroke);
            to.setStrokeWidth(from.getStrokeWidth());
    }

}
