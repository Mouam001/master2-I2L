package drawing.commands;

import drawing.shapes.IShape;
import drawing.ui.DrawingPane;

import java.util.ArrayList;
import java.util.List;

public class DuplicateCommand implements ICommand {
    private final DrawingPane drawingPane;
    private final List<IShape> originals;
    private final List<IShape> duplicates = new ArrayList<>();

    public DuplicateCommand(DrawingPane drawingPane, List<IShape> selection) {
        this.drawingPane = drawingPane;
        this.originals = new ArrayList<>(selection);
    }

    @Override
    public void execute() {
        duplicates.clear();

        for (IShape shape : originals) {
            IShape duplicate = shape.duplicate();
            duplicates.add(duplicate);
            drawingPane.addShape(duplicate);
        }
        //Selectionner les copies
        drawingPane.clearSelection();
        for(IShape copy : duplicates) {
            copy.setSelected(true);
            drawingPane.getSelection().add(copy);
        }
    }

    @Override
    public void undo() {
        for(IShape copy : duplicates) {
            drawingPane.removeShape(copy);
        }
        drawingPane.clearSelection();
    }
}
