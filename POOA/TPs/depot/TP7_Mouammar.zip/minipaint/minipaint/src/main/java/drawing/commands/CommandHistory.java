package drawing.commands;

import drawing.exceptions.CommandException;
import drawing.ui.ErrorStatusBar;

import java.util.Stack;

public class CommandHistory {

    private final Stack<ICommand> undoStack = new Stack<>();
    private final Stack<ICommand> redoStack = new Stack<>();
    private ErrorStatusBar errorBar;

    public void setErrorBar(ErrorStatusBar bar) {
        this.errorBar = bar;
    }

    public void exec(ICommand cmd) {
        try{
            cmd.execute();
            undoStack.push(cmd);
            redoStack.push(cmd);
        } catch(CommandException e){
            System.out.println("nicolas");
            if(errorBar != null){
                errorBar.showError(e.getMessage());
            }
        }

    }
    // Annuler
    public void undo() {
        if(undoStack.isEmpty()) return;

        ICommand cmd = undoStack.pop();
        cmd.undo();
        redoStack.push(cmd);
    }

    // Refaire
    public void redo(){
        if(redoStack.isEmpty()) return;

        ICommand cmd = redoStack.pop();
        cmd.execute();
        undoStack.push(cmd);
    }


}
