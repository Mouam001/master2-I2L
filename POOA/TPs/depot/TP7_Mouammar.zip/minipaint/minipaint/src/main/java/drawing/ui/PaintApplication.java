package drawing.ui;

import drawing.handlers.*;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * Created by lewandowski on 20/12/2020.
 */
public class PaintApplication extends Application {

    public static final int WIDTH = 800;
    public static final int HEIGHT = 600;

    private Scene scene;
    private BorderPane root;
    private DrawingPane drawingPane;
    private StatutBar statutBar;

    @Override
    public void start(Stage primaryStage) throws Exception {
        root = new BorderPane();
        scene = new Scene(root, WIDTH, HEIGHT);

        root.getStylesheets().add(
                PaintApplication.class.getClassLoader().getResource(
                        "style/Paint.css").toExternalForm());

        // Zonne de dessin
        drawingPane = new DrawingPane();
        drawingPane.getStyleClass().add("drawingPane");
        root.setCenter(drawingPane);

       // ToolBar
        ToolBar toolBar = new ToolBar(drawingPane);
        root.setTop(toolBar);

        // Barre de bas
        statutBar = new StatutBar(drawingPane);
        ErrorStatusBar errorStatusBar = new ErrorStatusBar();


        // Contenu du bas
        VBox bottomsBars = new VBox();
        bottomsBars.getChildren().addAll(statutBar, errorStatusBar);

        root.setBottom(bottomsBars);

        //Lier l'hostorique à la barre d'erreur
        drawingPane.getCommandHistory().setErrorBar(errorStatusBar);

        primaryStage.setTitle("Drawing");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public DrawingPane getDrawingPane() {
        return drawingPane;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
