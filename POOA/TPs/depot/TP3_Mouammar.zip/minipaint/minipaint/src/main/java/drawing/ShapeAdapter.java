package drawing;

import javafx.scene.layout.Pane;
import javafx.scene.shape.Shape;

public class ShapeAdapter implements IShape {
    private final Shape adaptedShape;
    private boolean selected = false;

    public ShapeAdapter(Shape shape) {
        this.adaptedShape = shape;
    }

    @Override
    public boolean isSelected() {
        return selected;
    }

    @Override
    public void setSelected(boolean selected) {
        this.selected = selected;

        if(selected) {
            if(!adaptedShape.getStyleClass().contains("selected")) {
                adaptedShape.getStyleClass().add("selected");
            }

        } else {
            adaptedShape.getStyleClass().remove("selected");
        }
    }

    @Override
    public boolean isOn(double x, double y){
        return adaptedShape.getBoundsInParent().contains(x,y);
    }

    @Override
    public void offset(double dx, double dy){
        adaptedShape.setTranslateX(adaptedShape.getTranslateX() + dx);
        adaptedShape.setTranslateY(adaptedShape.getTranslateY() + dy);
    }

    @Override
    public void addShapeToPane(Pane pane){
        pane.getChildren().add(adaptedShape);
    }

    @Override
    public void removeShapeFromPane(Pane pane){
        pane.getChildren().remove(adaptedShape);
    }


    public Shape getAdaptedShape(){
        return adaptedShape;
    }

}
