package drawing;

import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

import java.util.ArrayList;
import java.util.List;

public class SelectionHandler implements EventHandler<MouseEvent> {
    private final DrawingPane drawingPane;
    private final List<IShape> selectedShapes = new ArrayList<>();

    public SelectionHandler(DrawingPane drawingPane) {
        this.drawingPane = drawingPane;
        drawingPane.addEventFilter(MouseEvent.MOUSE_PRESSED, this);
    }

    @Override
    public void handle(MouseEvent event) {
        if (!event.getEventType().equals(MouseEvent.MOUSE_PRESSED)) {
            return;
        }
        IShape clicked = null;

        // cherchée la forme cliquée
        for (IShape shape : drawingPane.getShapes()) {
            if (shape.isOn(event.getX(), event.getY())) {
                clicked = shape;
                break;
            }
        }

        // Si rien n'a été cliquée
        if (clicked == null) {
            clearSelection();
            drawingPane.notifySelectionChanged();
            return;
        }

        // selection multiple
        if (event.isShiftDown()) {
            if (selectedShapes.contains(clicked)) {
                clicked.setSelected(false);
                selectedShapes.remove(clicked);
            } else {
                clicked.setSelected(true);
                selectedShapes.add(clicked);
            }

            drawingPane.notifySelectionChanged();
            return;
        }

        clearSelection();
        clicked.setSelected(true);
        selectedShapes.add(clicked);
        drawingPane.notifySelectionChanged();
    }

    public List<IShape> getSelection() {
        return selectedShapes;
    }

    private void clearSelection() {
        for (IShape s : selectedShapes) {
            s.setSelected(false);
        }
        selectedShapes.clear();
    }
}
