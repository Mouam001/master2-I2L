package drawing;

import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.geometry.Insets;

public class StatutBar extends HBox implements Observer{
    private Label label;
    private DrawingPane drawingPane;

    public StatutBar(DrawingPane drawingPane) {
        this.drawingPane = drawingPane;
        label = new Label("Forms : 0");
        this.getChildren().add(label);
        this.setPadding(new Insets(5));
        this.setSpacing(5);
        this.getStyleClass().add("statusbar");
        this.drawingPane.addObserver(this);
    }

    public void update(){
        label.setText("Formes : " + drawingPane.getShapeCount());
    }
}
