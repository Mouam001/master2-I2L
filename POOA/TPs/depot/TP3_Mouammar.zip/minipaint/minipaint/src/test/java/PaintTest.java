import drawing.IShape;
import drawing.PaintApplication;
import drawing.ShapeAdapter;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.stage.Stage;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import org.junit.Test;
import org.testfx.framework.junit.ApplicationTest;

import java.util.Iterator;

import static org.junit.Assert.*;

public class PaintTest extends ApplicationTest {

    PaintApplication app;

    @Override
    public void start(Stage stage) {
        try {
            app = new PaintApplication();
            app.start(stage);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void should_draw_circle_programmatically() {
        interact(() -> {
                    app.getDrawingPane().addShape(new ShapeAdapter(new Ellipse(20, 20, 30, 30)));
                });
        Iterator it = app.getDrawingPane().getChildren().iterator();
        assertTrue(it.next() instanceof Ellipse);
        assertFalse(it.hasNext());
    }

    @Test
    public void should_draw_circle() {
        // given:
        clickOn("Circle");
        moveBy(60,60);

        // when:
        drag().dropBy(30,30);
        //press(MouseButton.PRIMARY); moveBy(30,30); release(MouseButton.PRIMARY);

        // then:
        Iterator it = app.getDrawingPane().getShapes().iterator();
        assertTrue(it.next() instanceof Ellipse);
        assertFalse(it.hasNext());
    }

    @Test
    public void should_draw_rectangle() {
        // given:
        clickOn("Rectangle");
        moveBy(0,60);

        // when:
        drag().dropBy(70,40);

        // then:
        Iterator it = app.getDrawingPane().getShapes().iterator();
        assertTrue(it.next() instanceof Rectangle);
        assertFalse(it.hasNext());
    }

    @Test
    public void should_draw_triangle() {
        //given
        clickOn("Triangle");
        moveBy(40,50);

        //when:
        drag().dropBy(160,160);

        //then
        Iterator<IShape> it = app.getDrawingPane().getChildren().iterator();
        assertTrue(it.next() instanceof javafx.scene.shape.Polygon);
        assertFalse(it.hasNext());

    }

    @Test
    public void show_update_statutsbar_when_shapes_shape(){
        interact(() -> {
            app.getDrawingPane().addShape(new ShapeAdapter( new Rectangle(0, 0, 50, 50)));
        });
        Label label = (Label) ((HBox) app.getDrawingPane().getParent().lookup(".statusbar")).getChildren().get(0);
        assertEquals("Formes : 1", label.getText());

        interact(() -> {
            app.getDrawingPane().clear();
        });
        assertEquals("Formes : 0", label.getText());
    }

    @Test
    public void should_clear() {
        // given:
        clickOn("Rectangle");
        moveBy(30,60).drag().dropBy(70,40);
        clickOn("Circle");
        moveBy(-30,160).drag().dropBy(70,40);

        // when:
        clickOn("Clear");

        // then:
        assertFalse(app.getDrawingPane().getShapes().iterator().hasNext());
    }



}