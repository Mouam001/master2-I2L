package drawing.shapes;

import javafx.beans.value.ObservableValue;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Shape;

public interface IShape {
    boolean isSelected();
    void setSelected(boolean selected);
    boolean isOn(double x, double y);
    void offset(double x, double y);
    void addShapeToPane(Pane pane);
    void removeShapeFromPane(Pane pane);
    Shape getAdaptedShape();
    IShape duplicate();

    // Observer / Binding : deplacmenet brut
   // ObservableValue<Number> translateXProperty();
    //ObservableValue<Number> translateYProperty();

    // Bulding / Observer : posotion utilie
    ObservableValue<Number> centerXProperty();
    ObservableValue<Number> centerYProperty();


}
