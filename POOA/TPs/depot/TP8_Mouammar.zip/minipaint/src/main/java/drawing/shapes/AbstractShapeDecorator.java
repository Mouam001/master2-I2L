package drawing.shapes;

import javafx.beans.value.ObservableValue;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Shape;

public abstract class AbstractShapeDecorator implements IShape {
    protected final IShape decorated;

    protected AbstractShapeDecorator(IShape decorated) {
        this.decorated = decorated;
    }

    @Override
    public boolean isSelected(){
        return decorated.isSelected();
    };

    @Override
    public void setSelected(boolean selected){
        decorated.setSelected(selected);
    };

    @Override
   public  boolean isOn(double x, double y){
        return decorated.isOn(x, y);
    };

    @Override
    public void offset(double x, double y){
        decorated.offset(x, y);
    };

    @Override
   public void addShapeToPane(Pane pane){
        decorated.addShapeToPane(pane);
    };

    @Override
    public void removeShapeFromPane(Pane pane){
        decorated.removeShapeFromPane(pane);
    };

    @Override
    public Shape getAdaptedShape(){
        return decorated.getAdaptedShape();
    };

    @Override
    public IShape duplicate(){
        return decorated.duplicate();
    };

   /* @Override
    public ObservableValue<Number> translateXProperty(){
        return decorated.translateXProperty();
    }
    @Override
    public ObservableValue<Number> translateYProperty(){
        return decorated.translateYProperty();
    }*/

    @Override
    public ObservableValue<Number> centerXProperty(){
        return decorated.centerXProperty();
    }

    @Override
    public ObservableValue<Number> centerYProperty(){
        return decorated.centerYProperty();
    }





}
