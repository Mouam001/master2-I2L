package drawing.shapes;

import javafx.beans.value.ObservableValue;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;
import javafx.scene.shape.Shape;

public class Edge implements IShape{

    private final IShape from;
    private final IShape to;
    private final Line line = new Line();

    private boolean selected = false;

    public Edge(IShape from, IShape to) {
        this.from = from;
        this.to = to;

        // Binding des extremités
        line.startXProperty().bind(from.centerXProperty());
        line.startYProperty().bind(from.centerYProperty());
        line.endXProperty().bind(to.centerXProperty());
        line.endYProperty().bind(to.centerYProperty());
    }

    @Override
    public void addShapeToPane(Pane pane){
        pane.getChildren().add(line);
    }

    @Override
    public void removeShapeFromPane(Pane pane){
        pane.getChildren().remove(line);
    }

    @Override
    public boolean isOn(double x, double y){
        return line.contains(x, y);
    }

    @Override
    public void offset(double x, double y){}

    @Override
    public boolean isSelected(){
        return selected;
    }

    @Override
    public void setSelected(boolean selected){
        this.selected = selected;
        if(selected){
            if(!line.getStyleClass().contains("selected")){
                line.getStyleClass().add("selected");
            }else {
                line.getStyleClass().remove("selected");
            }
        }
    }

    @Override
    public Shape getAdaptedShape(){
        return line;
    }

    @Override
    public IShape duplicate() {
        throw new UnsupportedOperationException("Un Edge ne peux pas être dupliqué");
    }

    @Override
    public ObservableValue<Number> centerXProperty(){
        return line.startXProperty().add(line.endXProperty()).divide(2);
    }

    @Override
    public ObservableValue<Number> centerYProperty(){
        return line.startYProperty().add(line.endYProperty()).divide(2);
    }


}
