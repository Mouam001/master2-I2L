package drawing.handlers;

import drawing.commands.AddEdgeCommand;
import drawing.commands.ICommand;
import drawing.ui.DrawingPane;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class AddEdgeButtonHandler implements EventHandler<ActionEvent> {
    private final DrawingPane drawingPane;

    public AddEdgeButtonHandler(DrawingPane drawingPane) {
        this.drawingPane = drawingPane;
    }

    @Override
    public void handle(ActionEvent event) {
        ICommand command = new AddEdgeCommand(drawingPane);
        drawingPane.getCommandHistory().exec(command);
    }
}
