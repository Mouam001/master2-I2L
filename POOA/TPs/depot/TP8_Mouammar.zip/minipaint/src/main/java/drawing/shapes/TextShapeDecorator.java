package drawing.shapes;

import drawing.exceptions.CommandException;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;

public class TextShapeDecorator extends AbstractShapeDecorator {

    private final Text text;
    public TextShapeDecorator(IShape shape,  String content) {
        super(shape);

        if(shape instanceof GroupeShape){
            throw new CommandException("Impossible d'ajouter du texte à un groupe");
        }
        text = new Text(content);
        text.xProperty().bind(decorated.centerXProperty());
        text.yProperty().bind(decorated.centerYProperty());

    }

    @Override
    public void addShapeToPane(Pane pane){
        super.addShapeToPane(pane);
        pane.getChildren().add(text);
    }

    @Override
    public void removeShapeFromPane(Pane pane){
        pane.getChildren().remove(text);
        super.removeShapeFromPane(pane);

    }

    @Override
    public void offset(double x, double y){
        decorated.offset(x, y);
    }


}
