package drawing.shapes;

import java.util.ArrayList;
import java.util.List;

import javafx.beans.binding.Bindings;
import javafx.beans.value.ObservableValue;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Shape;

import javax.naming.Binding;

public class GroupeShape  implements IShape{
    private List<IShape> children = new ArrayList<>();
    private boolean selected = false;

    public GroupeShape(List<IShape> shapes) {
        children.addAll(shapes);
    }

    public List<IShape> getChildren() {
        return children;
    }

    @Override
    public boolean isSelected() {
        return selected;
    }

    @Override
    public void setSelected(boolean selected) {
        this.selected = selected;

        //selection des enfants
        for(IShape shape : children) {
            shape.setSelected(selected);
        }
    }

    @Override
    public boolean isOn(double x, double y) {
        for(IShape shape : children) {
            if(shape.isOn(x, y)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void offset(double dx, double dy) {
        for(IShape shape : children) {
            shape.offset(dx, dy);
        }
    }

    @Override
    public void addShapeToPane(Pane pane){
        for(IShape shape : children) {
            shape.addShapeToPane(pane);
        }
    }

    @Override
    public void removeShapeFromPane(Pane pane){
        for(IShape shape : children) {
            shape.removeShapeFromPane(pane);
        }
    }

    public Shape getAdaptedShape(){
        return null;
    }

    public IShape duplicate(){
        List<IShape> copies = new ArrayList<>();
        for(IShape shape : children) {
            copies.add(shape.duplicate());
        }
        return new GroupeShape(copies);
    }

    // Observer / Buiilding
    @Override
    public ObservableValue<Number> centerXProperty(){
        return Bindings.createDoubleBinding(
                () -> children.stream()
                        .mapToDouble(s -> s.centerXProperty().getValue().doubleValue())
                        .average()
                        .orElse(0),
                children.stream()
                        .map(IShape::centerXProperty)
                        .toArray(ObservableValue[]::new)
        );
    }

    @Override
    public ObservableValue<Number> centerYProperty(){
        return Bindings.createDoubleBinding(
                () -> children.stream()
                        .mapToDouble(s -> s.centerYProperty().getValue().doubleValue())
                        .average()
                        .orElse(0),
                children.stream()
                        .map(IShape::centerYProperty)
                        .toArray(ObservableValue[]::new)
        );
    }/*
    @Override
    public ObservableValue<Number> translateXProperty(){
        return centerXProperty();
    }

    @Override
    public ObservableValue<Number> translateYProperty(){
        return centerYProperty();
    }
    */
}
